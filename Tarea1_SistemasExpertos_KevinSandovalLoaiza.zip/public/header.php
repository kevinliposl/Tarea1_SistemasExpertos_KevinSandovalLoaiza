<!DOCTYPE html>
<html lang="es" >
    <head>
        <meta charset="UTF-8">
        <title>Tarea1_SistemasExpertos_KevinSandovalLoaiza</title>
        <link rel="stylesheet" href="public/css/style.css">

        <link rel="icon" href="public/img/favicon.ico" type="image/x-icon"/>
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/globals.js"></script>
    </head>
    <body>